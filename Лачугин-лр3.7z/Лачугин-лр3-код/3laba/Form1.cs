﻿using System;
using System.Windows.Forms;

namespace _3laba
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int[,] matrix = {
                { 1, 2, 3 },
                { 2, 2, 3 },
                { 3, 2, 3 }
            };

            string inputText = textBox1.Text.ToUpper();

            // Проверяем длину текста и дополняем пробелами, если необходимо
            if (inputText.Length % 3 != 0)
            {
                int paddingLength = 3 - (inputText.Length % 3);
                inputText = inputText.PadRight(inputText.Length + paddingLength, ' ');
            }

            int chunkCount = inputText.Length / 3;
            int[] finalOutput = new int[chunkCount * 3];

            for (int i = 0; i < chunkCount; i++)
            {
                int[] vector = new int[3];
                for (int j = 0; j < 3; j++)
                {
                    vector[j] = CharToIndex(inputText[i * 3 + j]);
                }
                int[] result = MatrixVectorProduct(matrix, vector);
                for (int j = 0; j < 3; j++)
                {
                    finalOutput[i * 3 + j] = result[j];
                }
            }

            textBox2.Clear();
            foreach (int value in finalOutput)
            {
                textBox2.Text += (value + " ");
            }

            string inputText2 = textBox3.Text;
            textBox4.Clear();

            int[] weights = { 1, 5, 8, 11, 15 };

            foreach (char character in inputText2)
            {
                int charPosition = GetCharPosition(character);

                if (charPosition == -1)
                {
                    continue;
                }

                string binaryRepresentation = Convert.ToString(charPosition, 2).PadLeft(weights.Length, '0');
                int[] weightedResult = new int[binaryRepresentation.Length];
                int totalSum = 0;

                for (int i = 0; i < binaryRepresentation.Length; i++)
                {
                    int binaryDigit = binaryRepresentation[i] - '0';
                    weightedResult[i] = binaryDigit * weights[i];
                    totalSum += weightedResult[i];
                }

                textBox4.Text += totalSum.ToString() + " ";
            }
        }

        static int GetCharPosition(char character)
        {
            if (character >= 'А' && character <= 'Я')
            {
                return character - 'А' + 1;
            }
            else if (character >= 'а' && character <= 'я')
            {
                return character - 'а' + 1;
            }

            return -1;
        }

        static int CharToIndex(char letter)
        {
            string alphabet = "АБВГДЕЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯ_";
            int index = alphabet.IndexOf(letter);
            return index >= 0 ? index + 1 : 0;
        }

        static int[] MatrixVectorProduct(int[,] matrix, int[] vector)
        {
            int[] result = new int[3];

            for (int i = 0; i < 3; i++)
            {
                result[i] = 0;
                for (int j = 0; j < 3; j++)
                {
                    result[i] += matrix[i, j] * vector[j];
                }
            }

            return result;
        }
    }
}