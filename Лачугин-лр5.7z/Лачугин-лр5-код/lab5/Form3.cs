﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace lab5
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        // Метод для кодирования по Хэммингу
        static string EncodeHamming(string data)
        {
            int hammingSize = 21;
            int[] bits = new int[hammingSize];
            int[] dataBits = Array.ConvertAll(data.ToCharArray(), c => int.Parse(c.ToString()));

            int j = 0;
            for (int i = 1; i <= hammingSize; i++)
            {
                if (IsPowerOfTwo(i))
                    bits[i - 1] = 0;
                else
                    bits[i - 1] = dataBits[j++];
            }

            for (int i = 0; i < 5; i++)
            {
                int parityBitIndex = (1 << i) - 1;
                int parity = 0;

                for (int k = 0; k < hammingSize; k++)
                {
                    if (((k + 1) & (1 << i)) != 0)
                        parity ^= bits[k];
                }
                bits[parityBitIndex] = parity;
            }

            return string.Join("", bits);
        }

        // Метод для декодирования по Хэммингу
        static string DecodeHamming(string encodedData)
        {
            int[] bits = Array.ConvertAll(encodedData.ToCharArray(), c => int.Parse(c.ToString()));
            int errorPosition = 0;

            for (int i = 0; i < 5; i++)
            {
                int parityBitIndex = (1 << i) - 1;
                int parity = 0;

                for (int k = 0; k < bits.Length; k++)
                {
                    if (((k + 1) & (1 << i)) != 0)
                        parity ^= bits[k];
                }

                if (parity != 0)
                    errorPosition += (1 << i);
            }

            if (errorPosition > 0 && errorPosition <= bits.Length)
            {
                bits[errorPosition - 1] ^= 1;
                MessageBox.Show($"Обнаружена и исправлена ошибка в позиции {errorPosition}");
            }
            List<int> dataBits = new List<int>();
            for (int i = 1; i <= bits.Length; i++)
            {
                if (!IsPowerOfTwo(i))
                    dataBits.Add(bits[i - 1]);
            }

            return string.Join("", dataBits);
        }

        // Вспомогательная функция для проверки степени двойки
        static bool IsPowerOfTwo(int x)
        {
            return (x & (x - 1)) == 0;
        }

        // Метод для преобразования строки в бинарный вид
        static string StringToBinary(string data)
        {
            string binary = "";
            foreach (char c in data)
            {
                binary += Convert.ToString(c, 2).PadLeft(8, '0');
            }
            return binary;
        }

        // Метод для преобразования бинарного вида в строку
        static string BinaryToString(string binaryData)
        {
            string text = "";
            for (int i = 0; i < binaryData.Length; i += 8)
            {
                string byteString = binaryData.Substring(i, Math.Min(8, binaryData.Length - i));
                char character = (char)Convert.ToInt32(byteString, 2);
                text += character;
            }
            return text.TrimEnd('\0');
        }

        // Метод для разделения строки на блоки
        static List<string> DivideIntoBlocks(string data, int blockSize)
        {
            List<string> blocks = new List<string>();
            for (int i = 0; i < data.Length; i += blockSize)
            {
                string block = data.Substring(i, Math.Min(blockSize, data.Length - i));
                if (block.Length < blockSize)
                {
                    block = block.PadRight(blockSize, '0'); // Дополнение нулями до нужной длины
                }
                blocks.Add(block);
            }
            return blocks;
        }

        // Метод для обработки кодирования и декодирования
        private void button2_Click_1(object sender, EventArgs e)
        {
            textBox9.Clear();
            string message = textBox5.Text;
            string binaryMessage = StringToBinary(message);
            List<string> blocks = DivideIntoBlocks(binaryMessage, 16);

            textBox9.AppendText("Исходное сообщение: " + message + Environment.NewLine);
            textBox9.AppendText("Бинарный вид: " + binaryMessage + Environment.NewLine + Environment.NewLine);

            List<string> encodedBlocks = new List<string>();

            foreach (var block in blocks)
            {
                string encodedBlock = EncodeHamming(block);
                encodedBlocks.Add(encodedBlock);
                string correspondingText = BinaryToString(block);

                textBox9.AppendText($"Буквы: \"{correspondingText}\" бинарный: {block} Кодированный: {encodedBlock}{Environment.NewLine}");
            }
            List<string> decodedBlocks = new List<string>();

            foreach (var encodedBlock in encodedBlocks)
            {
                string decodedBlock = DecodeHamming(encodedBlock);
                decodedBlocks.Add(decodedBlock);
                string correspondingText = BinaryToString(decodedBlock);
            }

            string decodedMessage = BinaryToString(string.Join("", decodedBlocks));
            textBox6.Text = decodedMessage;
        }
    }
}