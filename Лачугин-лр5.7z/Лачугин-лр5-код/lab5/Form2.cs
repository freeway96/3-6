﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace lab5
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string inputPath = "book.txt";

            if (!File.Exists(inputPath))
            {
                ShowError($"Файл {inputPath} не найден. Убедитесь, что файл находится в папке с приложением.");
                return;
            }

            string inputText = File.ReadAllText(inputPath);

            if (string.IsNullOrEmpty(inputText))
            {
                ShowError("Файл пуст. Введите текст для кодирования.");
                return;
            }

            inputText = FilterText(inputText);

            if (string.IsNullOrEmpty(inputText))
            {
                ShowError("После фильтрации управляющих символов текст оказался пустым.");
                return;
            }

            textBox1.Text = inputText;

            var huffman = new HuffmanCoding();
            huffman.ProcessText(inputText);

            textBox2.Text = huffman.EncodedText;
            textBox3.Clear();
            textBox3.AppendText("Таблица кодирования:\r\n");

            foreach (var entry in huffman.EncodeTable)
            {
                int frequency = huffman.Frequencies[entry.Key];
                textBox3.AppendText($"'{entry.Key}' -> {entry.Value} (повторений: {frequency})\r\n");
            }
        }

        private void ShowError(string message)
        {
            MessageBox.Show(message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        private string FilterText(string text)
        {
            return new string(text.Where(c => !char.IsControl(c) || c == ' ').ToArray());
        }

        public class HuffmanCoding
        {
            public Dictionary<char, string> EncodeTable { get; private set; }
            public Dictionary<char, int> Frequencies { get; private set; }
            public string EncodedText { get; private set; }

            public HuffmanCoding()
            {
                EncodeTable = new Dictionary<char, string>();
                Frequencies = new Dictionary<char, int>();
            }

            public void ProcessText(string inputText)
            {
                Frequencies = GetFrequencies(inputText);
                var root = BuildTree(Frequencies);
                BuildEncodeTable(root);
                EncodedText = Encode(inputText);
            }

            private Dictionary<char, int> GetFrequencies(string text)
            {
                return text.GroupBy(c => c).ToDictionary(g => g.Key, g => g.Count());
            }

            private HuffmanNode BuildTree(Dictionary<char, int> frequencies)
            {
                var priorityQueue = new List<HuffmanNode>(frequencies.Select(kvp => new HuffmanNode { Symbol = kvp.Key, Frequency = kvp.Value }));
                priorityQueue = priorityQueue.OrderBy(node => node.Frequency).ToList();

                while (priorityQueue.Count > 1)
                {
                    var left = priorityQueue[0];
                    var right = priorityQueue[1];
                    priorityQueue.RemoveRange(0, 2);

                    var parent = new HuffmanNode
                    {
                        Symbol = '\0',
                        Frequency = left.Frequency + right.Frequency,
                        Left = left,
                        Right = right
                    };

                    priorityQueue.Add(parent);
                    priorityQueue = priorityQueue.OrderBy(node => node.Frequency).ToList();
                }

                return priorityQueue[0];
            }

            private void BuildEncodeTable(HuffmanNode root, string code = "")
            {
                if (root == null) return;

                if (root.IsLeaf)
                {
                    EncodeTable[root.Symbol] = code;
                }

                BuildEncodeTable(root.Left, code + "0");
                BuildEncodeTable(root.Right, code + "1");
            }

            private string Encode(string input)
            {
                return string.Concat(input.Select(c => EncodeTable[c]));
            }
        }

        public class HuffmanNode
        {
            public char Symbol { get; set; }
            public int Frequency { get; set; }
            public HuffmanNode Left { get; set; }
            public HuffmanNode Right { get; set; }
            public bool IsLeaf => Left == null && Right == null;
        }
    }
}