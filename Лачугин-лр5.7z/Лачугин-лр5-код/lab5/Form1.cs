﻿using System;
using System.Text;
using System.Windows.Forms;

namespace lab5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string input = "АБВГАБВГАБВГАБВГДДДЕЕЕДЕД";
            string encoded = RLE(input);
            textBox1.Text = encoded;
        }

        string RLE(string input)
        {
            if (string.IsNullOrEmpty(input))
                return "";
            StringBuilder encoded = new StringBuilder();
            int count = 1;

            for (int i = 1; i < input.Length; i++)
            {
                if (input[i] == input[i - 1])
                {
                    count++;
                }
                else
                {
                    if (count == 1)
                    {
                        encoded.Append("1").Append(input[i - 1]);
                    }
                    else
                    {
                        encoded.Append(count).Append(input[i - 1]);
                    }
                    count = 1;
                }
            }

            if (count == 1)
            {
                encoded.Append("1").Append(input[input.Length - 1]);
            }
            else
            {
                encoded.Append(count).Append(input[input.Length - 1]);
            }
            return encoded.ToString();
        }

        private void хэммингToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form2 form2 = new Form2();
            form2.Show();
        }

        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Form3 form3 = new Form3();
            form3.Show();
        }
    }
}