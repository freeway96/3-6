﻿using System;
using System.Collections.Generic;
using System.Linq;

class PlayfairCipher
{
    private char[,] keyMatrix;
    private const int Rows = 4;
    private const int Cols = 8;
    private const char SpecialChar = 'х'; // Символ для замены одинаковых символов подряд

    public PlayfairCipher(string key)
    {
        keyMatrix = GenerateKeyMatrix(key);
    }

    private char[,] GenerateKeyMatrix(string key)
    {
        char[,] matrix = new char[Rows, Cols];
        string alphabet = "абвгдежзийклмнопрстуфхцчшщъыьэюя";
        string keyWithoutDuplicates = new string(key.Distinct().ToArray());
        string fullKey = keyWithoutDuplicates + "_" + new string(alphabet.Except(keyWithoutDuplicates).ToArray());

        int index = 0;
        for (int i = 0; i < Rows; i++)
        {
            for (int j = 0; j < Cols; j++)
            {
                matrix[i, j] = fullKey[index++];
            }
        }

        return matrix;
    }

    private (int, int) FindPosition(char c)
    {
        for (int i = 0; i < Rows; i++)
        {
            for (int j = 0; j < Cols; j++)
            {
                if (keyMatrix[i, j] == c)
                {
                    return (i, j);
                }
            }
        }
        throw new ArgumentException($"Символ '{c}' не найден в матрице.");
    }

    public string Encrypt(string plainText)
    {
        plainText = plainText.Replace(" ", "_").ToLower();
        if (plainText.Length % 2 != 0)
        {
            plainText += SpecialChar;
        }

        string encryptedText = "";
        for (int i = 0; i < plainText.Length; i += 2)
        {
            char c1 = plainText[i];
            char c2 = plainText[i + 1];

            var (row1, col1) = FindPosition(c1);
            var (row2, col2) = FindPosition(c2);

            if (row1 == row2)
            {
                encryptedText += keyMatrix[row1, (col1 + 1) % Cols];
                encryptedText += keyMatrix[row2, (col2 + 1) % Cols];
            }
            else if (col1 == col2)
            {
                encryptedText += keyMatrix[(row1 + 1) % Rows, col1];
                encryptedText += keyMatrix[(row2 + 1) % Rows, col2];
            }
            else
            {
                encryptedText += keyMatrix[row1, col2];
                encryptedText += keyMatrix[row2, col1];
            }
        }

        return encryptedText;
    }

    public string Decrypt(string cipherText)
    {
        string decryptedText = "";
        for (int i = 0; i < cipherText.Length; i += 2)
        {
            char c1 = cipherText[i];
            char c2 = cipherText[i + 1];

            var (row1, col1) = FindPosition(c1);
            var (row2, col2) = FindPosition(c2);

            if (row1 == row2)
            {
                decryptedText += keyMatrix[row1, (col1 - 1 + Cols) % Cols];
                decryptedText += keyMatrix[row2, (col2 - 1 + Cols) % Cols];
            }
            else if (col1 == col2)
            {
                decryptedText += keyMatrix[(row1 - 1 + Rows) % Rows, col1];
                decryptedText += keyMatrix[(row2 - 1 + Rows) % Rows, col2];
            }
            else
            {
                decryptedText += keyMatrix[row1, col2];
                decryptedText += keyMatrix[row2, col1];
            }
        }

        return decryptedText;
    }

    public static void Main(string[] args)
    {
        string key = "дмитриевич";
        PlayfairCipher cipher = new PlayfairCipher(key);

        string plainText = "лачугин_иван";
        string encryptedText = cipher.Encrypt(plainText);
        string decryptedText = cipher.Decrypt(encryptedText);

        Console.WriteLine("Заданый ключ: " + key);
        Console.WriteLine("Исходный текст: " + plainText);
        Console.WriteLine("Зашифрованный текст: " + encryptedText);
        Console.WriteLine("Расшифрованный текст: " + decryptedText);
    }
}